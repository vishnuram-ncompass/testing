# Lambda Users CRUD API

A TypeScript AWS Lambda function that handles full CRUD operations for a `users.json` data store.

---

## Project Structure

```
lambda-users/
├── src/
│   ├── handler.ts      # Main Lambda entry point & route dispatcher
│   ├── response.ts     # HTTP response helpers
│   ├── types.ts        # TypeScript interfaces
│   └── users.json      # Seed data (in-memory store)
├── package.json
├── tsconfig.json
└── README.md
```

---

## API Routes

| Method | Path          | Description          |
|--------|---------------|----------------------|
| GET    | /users        | Get all users        |
| GET    | /users/{id}   | Get a user by ID     |
| POST   | /users        | Create a new user    |
| PUT    | /users/{id}   | Update a user        |
| DELETE | /users/{id}   | Delete a user        |

### POST / PUT Body Shape

```json
{
  "name": "Jane Doe",
  "email": "jane@example.com",
  "age": 30,
  "role": "user"
}
```

> `role` must be `"admin"` or `"user"`.

---

## Local Build & Package

```bash
# 1. Install dev dependencies
npm install

# 2. Compile TypeScript → dist/
npm run build

# 3. Build + zip in one step → lambda-users.zip
npm run package
```

---

## Deploy to AWS Lambda

### Via AWS Console

1. Run `npm run package` to produce `lambda-users.zip`
2. Open **AWS Lambda → Create Function**
3. Runtime: **Node.js 20.x**
4. Upload `lambda-users.zip` under **Code source → Upload from .zip file**
5. Set **Handler** to `handler.handler`

### Via AWS CLI

```bash
# Create the function
aws lambda create-function \
  --function-name users-api \
  --runtime nodejs20.x \
  --role arn:aws:iam::<ACCOUNT_ID>:role/<LAMBDA_ROLE> \
  --handler handler.handler \
  --zip-file fileb://lambda-users.zip

# Update code after changes
aws lambda update-function-code \
  --function-name users-api \
  --zip-file fileb://lambda-users.zip
```

---

## API Gateway Setup

1. Create a **REST API** in API Gateway
2. Add resource `/users` with methods: `GET`, `POST`
3. Add resource `/users/{id}` with methods: `GET`, `PUT`, `DELETE`
4. Enable **Lambda Proxy Integration** for all methods
5. Deploy the API to a stage (e.g. `prod`)

---

## Notes

- `users.json` is bundled into the Lambda zip. Because Lambda functions are stateless, data changes (POST/PUT/DELETE) are **in-memory only** and reset on cold starts.
- For persistence, swap the in-memory array for **DynamoDB**, **RDS**, or another store.
