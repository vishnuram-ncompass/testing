import { APIGatewayProxyEvent, APIGatewayProxyResult } from "aws-lambda";
import { randomUUID } from "crypto";
import { User, CreateUserBody, UpdateUserBody } from "./types";
import * as res from "./response";

// Load users from the bundled JSON file (acts as an in-memory store for this Lambda)
// In production, replace this with DynamoDB / RDS / etc.
import usersData from "./users.json";

const users: User[] = usersData as User[];

// ─── Route handlers ──────────────────────────────────────────────────────────

/** GET /users — return all users */
const getAllUsers = (): APIGatewayProxyResult => {
  return res.ok(users);
};

/** GET /users/{id} — return a single user */
const getUserById = (id: string): APIGatewayProxyResult => {
  const user = users.find((u) => u.id === id);
  if (!user) return res.notFound(`User with id "${id}" not found`);
  return res.ok(user);
};

/** POST /users — create a new user */
const createUser = (body: string | null): APIGatewayProxyResult => {
  if (!body) return res.badRequest("Request body is required");

  let payload: CreateUserBody;
  try {
    payload = JSON.parse(body) as CreateUserBody;
  } catch {
    return res.badRequest("Invalid JSON in request body");
  }

  const { name, email, age, role } = payload;
  if (!name || !email || age === undefined || !role) {
    return res.badRequest("Fields 'name', 'email', 'age', and 'role' are required");
  }
  if (!["admin", "user"].includes(role)) {
    return res.badRequest("'role' must be either 'admin' or 'user'");
  }

  const newUser: User = { id: randomUUID(), name, email, age, role };
  users.push(newUser);
  return res.created(newUser);
};

/** PUT /users/{id} — replace a user entirely */
const updateUser = (id: string, body: string | null): APIGatewayProxyResult => {
  if (!body) return res.badRequest("Request body is required");

  let payload: UpdateUserBody;
  try {
    payload = JSON.parse(body) as UpdateUserBody;
  } catch {
    return res.badRequest("Invalid JSON in request body");
  }

  const index = users.findIndex((u) => u.id === id);
  if (index === -1) return res.notFound(`User with id "${id}" not found`);

  // Merge existing user with incoming fields (PUT semantics: full replacement of provided fields)
  users[index] = { ...users[index], ...payload, id };
  return res.ok(users[index]);
};

/** DELETE /users/{id} — remove a user */
const deleteUser = (id: string): APIGatewayProxyResult => {
  const index = users.findIndex((u) => u.id === id);
  if (index === -1) return res.notFound(`User with id "${id}" not found`);

  users.splice(index, 1);
  return res.noContent();
};

// ─── Main handler ─────────────────────────────────────────────────────────────

export const handler = async (
  event: APIGatewayProxyEvent
): Promise<APIGatewayProxyResult> => {
  console.log("Event:", JSON.stringify(event, null, 2));

  const method = event.httpMethod?.toUpperCase();
  const id = event.pathParameters?.id;

  try {
    // OPTIONS pre-flight
    if (method === "OPTIONS") {
      return {
        statusCode: 200,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type",
        },
        body: "",
      };
    }

    switch (method) {
      case "GET":
        return id ? getUserById(id) : getAllUsers();

      case "POST":
        return createUser(event.body);

      case "PUT":
        if (!id) return res.badRequest("User ID is required in path for PUT");
        return updateUser(id, event.body);

      case "DELETE":
        if (!id) return res.badRequest("User ID is required in path for DELETE");
        return deleteUser(id);

      default:
        return res.badRequest(`Method "${method}" is not supported`);
    }
  } catch (err) {
    console.error("Unhandled error:", err);
    return res.internalError();
  }
};
