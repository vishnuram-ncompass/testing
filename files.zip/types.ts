export interface User {
  id: string;
  name: string;
  email: string;
  age: number;
  role: "admin" | "user";
}

export interface ApiResponse<T = unknown> {
  statusCode: number;
  headers: Record<string, string>;
  body: string;
}

export type CreateUserBody = Omit<User, "id">;
export type UpdateUserBody = Partial<Omit<User, "id">>;
