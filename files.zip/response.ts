import { ApiResponse } from "./types";

const headers = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

export const ok = <T>(data: T): ApiResponse => ({
  statusCode: 200,
  headers,
  body: JSON.stringify(data),
});

export const created = <T>(data: T): ApiResponse => ({
  statusCode: 201,
  headers,
  body: JSON.stringify(data),
});

export const noContent = (): ApiResponse => ({
  statusCode: 204,
  headers,
  body: "",
});

export const badRequest = (message: string): ApiResponse => ({
  statusCode: 400,
  headers,
  body: JSON.stringify({ error: message }),
});

export const notFound = (message = "Resource not found"): ApiResponse => ({
  statusCode: 404,
  headers,
  body: JSON.stringify({ error: message }),
});

export const internalError = (message = "Internal server error"): ApiResponse => ({
  statusCode: 500,
  headers,
  body: JSON.stringify({ error: message }),
});
