import { Request, Response, NextFunction } from 'express';
import { responseHandler } from '../../../utils/response-handler';
import getDoctor from '../service/get-doctor.service';

const getDoctorController = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const result = await getDoctor({ email: req.params['email'] as string });
    responseHandler(
      res, 
      200, 
      'Doctor retrieved successfully.', 
      result
    );
  } 
  catch (error) {
    next(error);
  }
};

export default getDoctorController;
