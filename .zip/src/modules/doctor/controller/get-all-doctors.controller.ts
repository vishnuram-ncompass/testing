import { Request, Response, NextFunction } from 'express';
import { responseHandler } from '../../../utils/response-handler';
import getAllDoctors from '../service/get-all-doctors.service';

const getAllDoctorsController = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const result = await getAllDoctors();
    responseHandler(
      res, 
      200, 
      'Doctors retrieved successfully.', 
      result
    );
  } 
  catch (error) {
    next(error);
  }
};

export default getAllDoctorsController;
