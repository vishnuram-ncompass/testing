import { Request, Response, NextFunction } from 'express';
import { responseHandler } from '../../../utils/response-handler';
import addDoctor from '../service/add-doctor.service';
import { addDoctorBody } from '../../../types';

const addDoctorController = async (
  req: Request<object, object, addDoctorBody>,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const result = await addDoctor(req.body);
    responseHandler(
      res, 
      201, 
      'Doctor added successfully.', 
      result
    );
  } 
  catch (error) {
    next(error);
  }
};

export default addDoctorController;
