import { express } from '../../utils/packages';

// import { validate } from '../../middlewares/validate.middleware';
import { authenticate } from '../../middlewares/authenticate.middleware';
import { authorize } from '../../middlewares/authorize.middleware';
import { compress } from '../../middlewares/compress.middleware';

// import { addDoctorSchema, searchDoctorSchema } from './doctor.schema';
import addDoctorController from './controller/add-doctor.controller';
import getAllDoctorsController from './controller/get-all-doctors.controller';
import getDoctorController from './controller/get-doctor.controller';

import validater from '../../middlewares/validate';
import { addDoctorSchema } from './schema/add-doctor.schema';
import { searchDoctorSchema } from './schema/search-doctor.schema';

const router = express.Router();

router.use(authenticate);

router.post(
  '/',
  authorize('admin'),
  // validate(addDoctorSchema, 'body'),
  validater( addDoctorSchema ),
  addDoctorController
);

router.get(
  '/',
  authorize('admin', 'doctor'),
  compress(),
  getAllDoctorsController
);

router.get(
  '/:email',
  authorize('admin', 'doctor'),
  // validate(searchDoctorSchema, 'params'),
  validater( searchDoctorSchema , 'params' ),
  getDoctorController
);

export default router;
