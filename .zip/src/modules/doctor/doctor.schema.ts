import { Joi } from '../../utils/packages';
import { supportedSpecialization } from '../../types';

const supportedSpecializations: supportedSpecialization[] = [
  'cardiology', 
  'neurology', 
  'orthopedics', 
  'dermatology',
  'pediatrics', 
  'oncology', 
  'gastroenterology', 
  'urology',
  'psychiatry', 
  'radiology', 
  'ophthalmology', 
  'ent',
];

export const addDoctorSchema = Joi.object({

  name: Joi
    .string()
    .pattern(/^[A-Za-z\s]+$/)
    .min(2)
    .max(100)
    .required()
    .messages({
      'string.pattern.base' : 
        'Invalid name',
      'string.min' : 
        'Name must be at least 2 characters.',
      'string.max' : 
        'Name must be at most 100 characters.',
      'any.required' : 
        'Name is required.',
    }),

  email: Joi
    .string()
    .email()
    .pattern(/^[a-zA-Z0-9._%+-]+@gemhospital\.com$/)
    .required()
    .messages({
      'string.email' : 
        'Please provide a valid email address.',
      'string.pattern.base' : 
        'Use email format followed by the hospital domain.',
      'any.required' : 
        'Email is required.',
    }),

  password: Joi
    .string()
    .min(8)
    .required()
    .messages({
      'string.min' : 
        'Password must be at least 8 characters.',
      'any.required' : 
        'Password is required.',
    }),

  supportedSpecialization: Joi
    .string()
    .pattern(/^[A-Za-z\s]+$/)
    .trim()
    .lowercase()
    .valid(...supportedSpecializations)
    .required()
    .messages({
      'string.pattern.base' :   
        'Invalid supportedSpecialization.',
      'any.only' :    
        'Invalid supportedSpecialization.',
      'any.required' :    
        'supportedSpecialization is required.',
    }),

  consultationFee: Joi
    .number()
    .positive()
    .precision(2)
    .required()
    .messages({
      'number.base'     : 
        'Consultation fee must be a number.',
      'number.positive' : 
        'Consultation fee must be a positive value.',
      'any.required'    : 
        'Consultation fee is required.',
    }),

  phoneNumber: Joi
    .string()
    .pattern(/^\d{10}$/)
    .optional()
    .messages({
      'string.pattern.base' : 
        'Please provide a valid phone number.',
    }),

  dateOfBirth: Joi
    .date()
    .iso()
    .less('now')
    .required()
    .messages({
      'date.base'    : 
        'Date of birth must be a valid date.',
      'date.format'  : 
        'Date should be in YYYY-MM-DD format.',
      'date.less'    : 
        'Date of birth must be in the past.',
      'any.required' : 
        'Date of birth is required.',
    }),
});

export const searchDoctorSchema = Joi.object({
  email: Joi
    .string()
    .email()
    .pattern(/^[a-zA-Z0-9._%+-]+@gemhospital\.com$/)
    .required()
    .messages({
      'string.email'        : 
        'Please provide a valid email address.',
      'string.pattern.base' : 
        'Use email format followed by the hospital domain.',
      'any.required'        : 
        'Email is required.',
    }),
});
