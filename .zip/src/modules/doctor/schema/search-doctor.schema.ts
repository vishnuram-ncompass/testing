import {
    IsEmail,
    IsNotEmpty,
    Matches
} from "class-validator";

export class searchDoctorSchema {

    @IsEmail({}, {
        message: "Please provide a valid email address."
    })
    @Matches(
        /^[a-zA-Z0-9._%+-]+@gemhospital\.com$/,
        {
            message:
                "Use email format followed by the hospital domain."
        }
    )
    @IsNotEmpty({
        message: "Email is required."
    })
    email!: string;
}