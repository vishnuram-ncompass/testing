import { Expose, Transform, Type } from "class-transformer";
import {
    IsDate,
    IsEmail,
    IsNotEmpty,
    IsNumber,
    IsOptional,
    Matches,
    MaxLength,
    MinLength,
    Validate,
    IsIn,
    IsPositive
} from "class-validator";

import { IsPastDateConstraint } from "../../../validators/past-validator";

export const supportedSpecializations = [
    "cardiology",
    "neurology",
    "orthopedics",
    "dermatology",
    "pediatrics",
    "oncology",
    "gastroenterology",
    "urology",
    "psychiatry",
    "radiology",
    "ophthalmology",
    "ent",
] as const;

export class addDoctorSchema {

    @Matches(/^[A-Za-z\s]+$/, {
        message: "Invalid name"
    })
    @MinLength(2, {
        message: "Name must be at least 2 characters."
    })
    @MaxLength(100, {
        message: "Name must be at most 100 characters."
    })
    @IsNotEmpty({
        message: "Name is required."
    })
    name!: string;

    @IsEmail({}, {
        message: "Please provide a valid email address."
    })
    @Matches(/^[a-zA-Z0-9._%+-]+@gemhospital\.com$/, {
        message: "Use email format followed by the hospital domain."
    })
    @IsNotEmpty({
        message: "Email is required."
    })
    email!: string;

    @MinLength(8, {
        message: "Password must be at least 8 characters."
    })
    @IsNotEmpty({
        message: "Password is required."
    })
    password!: string;

    @Transform(({ value }) =>
        typeof value === "string"
            ? value.trim().toLowerCase()
            : value
    )
    @Matches(/^[A-Za-z\s]+$/, {
        message: "Invalid supportedSpecialization."
    })
    @IsIn(supportedSpecializations, {
        message: "Invalid supportedSpecialization."
    })
    @IsNotEmpty({
        message: "supportedSpecialization is required."
    })
    specialization!: string;

    @Type(() => Number)
    @IsNumber(
        { maxDecimalPlaces: 2 },
        {
            message: "Consultation fee must be a number."
        }
    )
    @IsPositive({
        message: "Consultation fee must be a positive value."
    })
    consultationFee!: number;

    @IsOptional()
    @Matches(/^\d{10}$/, {
        message: "Please provide a valid phone number."
    })
    phoneNumber?: string;

    @Type(() => Date)
    @IsDate({
        message: "Date of birth must be a valid date."
    })
    @Validate(IsPastDateConstraint)
    dateOfBirth!: Date;
}