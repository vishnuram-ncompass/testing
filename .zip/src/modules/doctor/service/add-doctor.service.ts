import { ConflictError } from '../../../utils/app-error';
import { executeTransaction } from '../../../utils/db';
import { bcrypt } from '../../../utils/packages';
import { addDoctorBody, doctorResult, insertResult } from '../../../types';
import { PoolConnection } from 'mysql2/promise';

const findUserByEmailQuery = `
  SELECT 
      u.uid 
    FROM users u
  WHERE 
    u.email = ? 
    AND 
    u.deleted_at IS NULL`;

const insertUserQuery = `
  INSERT INTO users (
    name, 
    email, 
    phone_number, 
    date_of_birth, 
    role
  )
  VALUES (?, ?, ?, ?, 'doctor')`;

const insertPasswordQuery = `
  INSERT INTO passwords (
    uid, 
    hashed_password
  ) 
  VALUES (?, ?)`;

const insertDoctorQuery = `
  INSERT INTO doctors (
    uid, 
    specialization, 
    consultation_fee
  )
  VALUES (?, ?, ?)`;

const getNewDocQuery = `
  SELECT
      u.name,
      u.email,
      u.phone_number AS phoneNumber,
      d.specialization,
      d.consultation_fee AS consultationFee
    FROM users u
  INNER JOIN doctors d 
    ON d.uid = u.uid
  WHERE u.uid = ?`;

interface newDocRow {
  name: string;
  email: string;
  phoneNumber: string | null;
  specialization: doctorResult['specialization'];
  consultationFee: number;
}

const addDoctor = async ({
  name,
  email,
  password,
  specialization,
  consultationFee,
  phoneNumber = undefined,
  dateOfBirth,
}: addDoctorBody): Promise<doctorResult> => {
  return executeTransaction(async (conn: PoolConnection) => {
    const [existing] = await conn.query(findUserByEmailQuery, [email]) as [unknown[], unknown];

    if ((existing as unknown[]).length !== 0) {
      throw new ConflictError('Doctor already exists.');
    }

    const [userResult] = await conn.query(insertUserQuery, [
      name, email, phoneNumber, dateOfBirth,
    ]) as [insertResult, unknown];

    const uid = userResult.insertId;
    const hashedPassword = await bcrypt.hash(password, 10);

    await conn.query(insertPasswordQuery, [uid, hashedPassword]);
    await conn.query(insertDoctorQuery, [uid, specialization, consultationFee]);

    const [rows] = await conn.query(getNewDocQuery, [uid]) as [newDocRow[], unknown];
    const newDoctor = rows[0]!;

    return {
      name : newDoctor.name,
      email : newDoctor.email,
      contact : newDoctor.phoneNumber,
      specialization : newDoctor.specialization,
      consultationFee : newDoctor.consultationFee,
    };
  });
};

export default addDoctor;
