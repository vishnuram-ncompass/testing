import { executeQuery } from '../../../utils/db';
import { NotFoundError } from '../../../utils/app-error';
import { doctorRow, searchDoctorParams } from '../../../types';

const getDocByEmailQuery = `
  SELECT
      u.name,
      u.email,
      u.phone_number AS phoneNumber,
      d.specialization,
      d.consultation_fee AS consultationFee
    FROM users u
  INNER JOIN doctors d 
    ON d.uid = u.uid
  WHERE 
    u.email = ? 
    AND 
    u.deleted_at IS NULL`;

const getDoctor = async ({ email }: searchDoctorParams): Promise<doctorRow> => {
  const doctors = await executeQuery<doctorRow>(getDocByEmailQuery, [email]);

  if (!doctors.length) {
    throw new NotFoundError(
      'Doctor not found.'
    );
  }

  return doctors[0]!;
};

export default getDoctor;
