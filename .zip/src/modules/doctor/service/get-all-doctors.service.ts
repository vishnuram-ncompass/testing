import { executeQuery } from '../../../utils/db';
import { doctorRow } from '../../../types';

const getAllDocQuery = `
  SELECT
      u.name,
      u.email,
      u.phone_number AS phoneNumber,
      d.specialization,
      d.consultation_fee AS consultationFee
    FROM users u
  INNER JOIN doctors d
    ON d.uid = u.uid
  WHERE u.deleted_at IS NULL
  ORDER BY u.name ASC`;

const getAllDoctors = async (): Promise<doctorRow[]> => {
  return executeQuery<doctorRow>(getAllDocQuery);
};

export default getAllDoctors;
