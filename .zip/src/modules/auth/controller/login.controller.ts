import { Request, Response, NextFunction } from 'express';
import login from '../service/login.service';
import { loginBody } from '../../../types';
import { responseHandler } from '../../../utils/response-handler';

const loginController = async (
  req: Request<object, object, loginBody>,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const result = await login(req.body);
    responseHandler(
      res, 
      200, 
      'Logged in successfully.', 
      result
    );
  } 
  catch (error) {
    next(error);
  }
};

export default loginController;