import { Request, Response, NextFunction } from 'express';
import { responseHandler } from '../../../utils/response-handler';
import patientSignup from '../service/patient-signup.service';
import { patientSignupBody } from '../../../types';

const patientSignupController = async (
  req: Request<object, object, patientSignupBody>,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const result = await patientSignup(req.body);
    responseHandler(
      res, 
      201, 
      'Account created successfully.', 
      result
    );
  } 
  catch (error) {
    next(error);
  }
};

export default patientSignupController;
