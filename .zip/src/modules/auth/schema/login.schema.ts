import { Exclude, Expose } from "class-transformer";
import { IsEmail, IsNotEmpty } from "class-validator";

export class LoginSchema {

    // @Expose()
    @IsEmail({}, {
        message: "Please provide a valid email address."
    })
    @IsNotEmpty({
        message: "Email is required."
    })
    email!: string;

    // @Exclude()
    @IsNotEmpty({
        message: "Password is required."
    })
    password!: string;
}