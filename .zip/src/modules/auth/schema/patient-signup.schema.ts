import { Expose, Type } from "class-transformer";
import { IsDate , IsEmail , IsNotEmpty , Matches , MaxLength , MinLength , Validate } from "class-validator";
import { IsPastDateConstraint } from "../../../validators/past-validator";

export class patientSignupSchema {

    @Expose()
    @Matches(/^[A-Za-z\s]+$/, {
        message: "Invalid Name"
    })
    @MinLength(2, {
        message: "Name must be at least 2 characters."
    })
    @MaxLength(100, {
        message: "Name must be at most 100 characters."
    })
    @IsNotEmpty({
        message: "Name is required."
    })
    name!: string;

    @Expose()
    @IsEmail({}, {
        message: "Please provide a valid email address."
    })
    @IsNotEmpty({
        message: "Email is required."
    })
    email!: string;

    @Expose()
    @MinLength(8, {
        message: "Password must be at least 8 characters."
    })
    @IsNotEmpty({
        message: "Password is required."
    })
    password!: string;

    @Expose()
    @Type(() => Date)
    @IsDate({
        message: "Date of birth must be a valid date."
    })
    @Validate(IsPastDateConstraint)
    dateOfBirth!: Date;

    @Expose()
    @Matches(/^\d{10}$/, {
        message: "Please provide a valid phone number."
    })
    @IsNotEmpty({
        message: "Phone number is required."
    })
    phoneNumber!: string;
}