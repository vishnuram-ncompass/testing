import { express } from '../../utils/packages';
import { validate } from '../../middlewares/validate.middleware';
import validator from '../../middlewares/validate';
// import { patientSignupSchema, loginSchema } from './auth.schema';
// import { loginSchema } from './auth.schema';
import { patientSignupSchema } from './schema/patient-signup.schema';
import patientSignupController from './controller/patient-signup.controller';
import loginController from './controller/login.controller';
import { LoginSchema } from './schema/login.schema';

const router = express.Router();

router.post(
  '/signup',
  // validate(patientSignupSchema, 'body'),
  validator( patientSignupSchema ),
  patientSignupController
);

router.post(
  '/login',
  // validate(loginSchema, 'body'),
  validator( LoginSchema ),
  loginController
);

export default router;
