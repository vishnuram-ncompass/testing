import { AppError, ConflictError } from '../../../utils/app-error';
import { executeTransaction } from '../../../utils/db';
import { bcrypt } from '../../../utils/packages';
import { patientSignupBody, signupResult, insertResult } from '../../../types';
import { PoolConnection } from 'mysql2/promise';

const findUserByEmailQuery = `
  SELECT 
      u.uid 
    FROM users u
  WHERE 
    u.email = ? 
    AND 
    u.deleted_at IS NULL`;

const insertUserQuery = `
  INSERT INTO users (
    name, 
    email, 
    date_of_birth, 
    phone_number, 
    role
  )
  VALUES (?, ?, ?, ?, 'patient')`;

const insertPasswordQuery = `
  INSERT INTO passwords (
    uid, 
    hashed_password
  ) 
  VALUES (?, ?)` ;

const insertPatientQuery = `
  INSERT INTO patients (
    uid
  ) 
  VALUES (?)`;

const getNewUserQuery = `
  SELECT 
      u.name, 
      u.email, 
      u.role 
    FROM users u 
  WHERE u.uid = ?`;

interface newUserRow {
  name: string;
  email: string;
  role: string;
}

const patientSignup = async ({
  name,
  email,
  password,
  dateOfBirth,
  phoneNumber,
}: patientSignupBody): Promise<signupResult> => {
  return executeTransaction(async (conn: PoolConnection) => {
    const [existing] = await conn.query(findUserByEmailQuery, [email]) as [unknown[], unknown];

    if ((existing as unknown[]).length !== 0) {
      throw new ConflictError(
        'An account with this email already exists.'
      );
    }

    const [userResult] = await conn.query(insertUserQuery, [
      name, email, dateOfBirth, phoneNumber,
    ]) as [insertResult, unknown];

    const uid = userResult.insertId;
    const hashedPassword = await bcrypt.hash(password, 10);

    await conn.query(insertPasswordQuery, [uid, hashedPassword]);
    await conn.query(insertPatientQuery, [uid]);

    const [rows] = await conn.query(getNewUserQuery, [uid]) as [newUserRow[], unknown];
    const newUser = rows[0]!;

    return {
      [`${newUser.role}Details`]: {
        name  : newUser.name,
        email : newUser.email,
        role  : newUser.role,
      },
    };
  });
};

export default patientSignup;
