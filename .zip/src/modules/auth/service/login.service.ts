import { executeQuery } from '../../../utils/db';
import { AppError } from '../../../utils/app-error';
import { bcrypt, jwt } from '../../../utils/packages';
import { loginBody, loginResult } from '../../../types';

interface UserWithPassword {
  uid: number;
  name: string;
  email: string;
  role: string;
  hashedPassword: string;
}

const findUserByEmailQuery = `
  SELECT
      u.uid,
      u.name,
      u.email,
      u.role,
      p.hashed_password AS hashedPassword
    FROM users u
  INNER JOIN passwords p
    ON p.uid = u.uid
  WHERE
    u.email = ?
    AND
    u.deleted_at IS NULL`;

const login = async ( { email, password } : loginBody): Promise<loginResult> => {
  const users = await executeQuery<UserWithPassword>(findUserByEmailQuery, [email]);

  if (!users.length) {
    throw new AppError('Invalid email or password.', 401);
  }

  const user = users[0]!;
  const isPasswordCorrect = await bcrypt.compare(password, user.hashedPassword);

  if (!isPasswordCorrect) {
    throw new AppError('Invalid email or password.', 401);
  }

  const expiresIn = (process.env.JWT_EXPIRES_IN ?? '7d') as `${number}${'d'}`;
  const token = jwt.sign(
    { uid: user.uid },
    process.env.JWT_SECRET as string,
    { expiresIn }
  );

  return {
    [`${user.role} details`] : { email: user.email },
    token,
  };
};

export default login;
