import { express } from '../../utils/packages';
import { authenticate } from '../../middlewares/authenticate.middleware';
import { authorize } from '../../middlewares/authorize.middleware';
// import { validate } from '../../middlewares/validate.middleware';
import { compress } from '../../middlewares/compress.middleware';
// import { bookAppointmentSchema, rescheduleAppointmentSchema } from './appointment.schema';
import bookAppointmentController from './controller/book-appointment.controller';
import cancelAppointmentController from './controller/cancel-appointment.controller';
import rescheduleAppointmentController from './controller/reschedule-appointment.controller';
import getTodayAppointmentsController from './controller/get-today-appointments.controller';
import getUpcomingAppointmentsController from './controller/get-upcoming-appointments.controller';
import getAppointmentHistoryController from './controller/get-appointment-history.controller';
import validater from '../../middlewares/validate';
import { bookAppointmentSchema } from './book-appt.schema';
import { rescheduleAppointment } from './reschedule-appt.schema';

const router = express.Router();

router.use(authenticate);

router.get(
  '/today',
  authorize('doctor', 'patient'),
  compress(),
  getTodayAppointmentsController
);

router.get(
  '/upcoming',
  authorize('doctor', 'patient'),
  compress(),
  getUpcomingAppointmentsController
);

router.get(
  '/history',
  authorize('doctor', 'patient'),
  compress(),
  getAppointmentHistoryController
);

router.post(
  '/',
  authorize('admin', 'patient'),
  // validate(bookAppointmentSchema, 'body'),
  validater( bookAppointmentSchema ),
  bookAppointmentController
);

router.put(
  '/:appointmentId/reschedule',
  authorize('admin', 'doctor', 'patient'),
  // validate(rescheduleAppointmentSchema, 'body'),
  validater( rescheduleAppointment ),
  rescheduleAppointmentController
);

router.delete(
  '/:appointmentId',
  authorize('admin', 'doctor', 'patient'),
  cancelAppointmentController
);

export default router;
