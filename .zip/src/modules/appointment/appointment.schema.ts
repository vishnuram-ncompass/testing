import { Joi } from '../../utils/packages';

export const bookAppointmentSchema = Joi.object({

  doctorEmail: Joi
    .string()
    .email()
    .pattern(/^[a-zA-Z0-9._%]+@gemhospital\.com$/)
    .required()
    .messages({
      'string.email': 'Please provide a valid email address.',
      'string.pattern.base' : 'Provide the correct hospital email of the doctor.',
      'any.required': 'Doctor email is required.',
    }),

  patientEmail: Joi
    .string()
    .email()
    .optional()
    .messages({
      'string.email' : 'Please provide a valid patient email.',
    }),

  scheduledAt: Joi
    .date()
    .greater('now')
    .required()
    .messages({
      'date.base': 'Enter a valid date.',
      'date.format': 'Date should be in YYYY-MM-DD format.',
      'date.greater' : "Can't set appointment in the past — select a future date.",
      'any.required' : 'Scheduled date is required.',
    }),
});

export const rescheduleAppointmentSchema = Joi.object({

  scheduledAt: Joi
    .date()
    .iso()
    .greater('now')
    .required()
    .messages({
      'date.base': 'Enter a valid date.',
      'date.format': 'Date should be in YYYY-MM-DD format.',
      'date.greater' : "Can't set appointment in the past — select a future date.",
      'any.required' : 'New scheduled date is required.',
    }),
});
