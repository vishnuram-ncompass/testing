import { Type } from "class-transformer";
import { IsDate, IsEmail, IsNotEmpty , Matches, MinDate } from "class-validator";

export class bookAppointmentSchema{
    @IsEmail(
        {},
        {
            message : "Enter a valid email..."
        }
    )
    @IsNotEmpty({
        message: "Email should not be empty..."
    })
    @Matches( /^[a-zA-Z0-9._]+@gemhospital\.com$/ , {
        message : "Use email provided but the hospital..."
    })
    doctorEmail !: string

    @IsEmail(
        {},
        {
            message : "Enter a valid email..."
        }
    )
    @IsNotEmpty({
        message: "Email should not be empty..."
    })

    patientEmail !: string

    @Type( () => Date )
    @IsDate({
        message : "Invalid date..."
    })
    @MinDate( new Date() , {
        message : "Appointment date must be in the future..."
    })
    @IsNotEmpty({
        message : "Please provide appointment date..."
    })
    scheduledAt !: string

}