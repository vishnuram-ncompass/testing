import { executeQuery } from '../../../utils/db';
import {
  authUser,
  doctorAppointmentHistoryRow,
  patientAppointmentHistoryRow,
} from '../../../types';

const getTodayForDocQuery = `
  SELECT
      p.name AS patientName,
      p.email AS patientEmail,
      a.scheduled_at AS scheduledAt,
      a.status
    FROM appointments a
  INNER JOIN users p 
    ON p.uid = a.patient_uid
  WHERE 
    a.doctor_uid = ?
    AND 
    DATE(a.scheduled_at) = CURDATE()
    AND 
    a.status = 'scheduled'
  ORDER BY a.scheduled_at ASC`;

const getTodayForPatientQuery = `
  SELECT
      d.name AS doctorName,
      d.email AS doctorEmail,
      dc.supportedSpecialization,
      dc.consultation_fee AS consultationFee,
      a.scheduled_at AS scheduledAt,
      a.status
    FROM appointments a
  INNER JOIN users d 
    ON d.uid = a.doctor_uid
  INNER JOIN doctors dc 
    ON dc.uid = a.doctor_uid
  WHERE 
    a.patient_uid = ?
    AND 
    DATE(a.scheduled_at) = CURDATE()
    AND 
    a.status = 'scheduled'
  ORDER BY a.scheduled_at ASC`;

interface getTodayInput {
  requester: authUser;
}

const getTodayAppointments = async ({
  requester,
}: getTodayInput): Promise<doctorAppointmentHistoryRow[] | patientAppointmentHistoryRow[]> => {
  if (requester.role === 'doctor') {
    return executeQuery<doctorAppointmentHistoryRow>(getTodayForDocQuery, [requester.uid]);
  }

  return executeQuery<patientAppointmentHistoryRow>(getTodayForPatientQuery, [requester.uid]);
};

export default getTodayAppointments;
