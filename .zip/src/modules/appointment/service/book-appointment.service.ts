import { executeTransaction } from '../../../utils/db';
import { NotFoundError, BadRequestError } from '../../../utils/app-error';
import { bookAppointmentBody, appointmentResult, insertResult } from '../../../types';
import { PoolConnection } from 'mysql2/promise';

const findDocByEmailQuery = `
  SELECT u.uid, u.name
    FROM users u
  INNER JOIN doctors d 
    ON d.uid = u.uid
  WHERE 
    u.email = ? 
    AND 
    u.deleted_at IS NULL`;

const findPatientByEmailQuery = `
  SELECT u.uid, u.name
    FROM users u
  INNER JOIN patients p 
    ON p.uid = u.uid
  WHERE 
    u.email = ?
    AND 
    u.deleted_at IS NULL
    AND 
    p.status = 'alive'`;

const findConflictingAppointmentQuery = `
  SELECT a.aid FROM appointments a
  WHERE 
    a.doctor_uid = ?
    AND 
    a.status = 'scheduled'
    AND 
    a.scheduled_at BETWEEN
      DATE_SUB(?, INTERVAL 29 MINUTE)
      AND
      DATE_ADD(?, INTERVAL 29 MINUTE)`;

const insertAppointmentQuery = `
  INSERT INTO appointments (
    doctor_uid, 
    patient_uid, 
    scheduled_at
    )
  VALUES (?, ?, ?)`;

const getNewAppointmentQuery = `
  SELECT
      d.name AS doctorName,
      p.name AS patientName,
      DATE_FORMAT(a.scheduled_at, '%Y-%m-%d %H:%i:%s') AS scheduledAt,
      a.status
    FROM appointments a
  INNER JOIN users d 
    ON d.uid = a.doctor_uid
  INNER JOIN users p 
    ON p.uid = a.patient_uid
  WHERE a.aid = ?`;

interface userLookupRow {
  uid: number;
  name: string;
}

interface newAppointmentRow {
  doctorName: string;
  patientName: string;
  scheduledAt: string;
  status: appointmentResult['status'];
}

const bookAppointment = async ({
  doctorEmail,
  patientEmail = undefined,
  scheduledAt,
  requester,
}: bookAppointmentBody): Promise<appointmentResult> => {
  return executeTransaction(async (conn: PoolConnection) => {
    const [doctorRows] = await conn.query(findDocByEmailQuery, [doctorEmail]) as [userLookupRow[], unknown];

    if (!doctorRows.length) {
      throw new NotFoundError('Doctor not found.');
    }

    const doctor = doctorRows[0]!;

    const normalizedAt = String(scheduledAt).replace(' ', 'T');

    let patientUid: number;

    if (requester.role === 'admin') {
      if (!patientEmail) {
        throw new BadRequestError(
          'Patient email is required when booking as admin.'
        );
      }

      const [patientRows] = await conn.query(findPatientByEmailQuery, [patientEmail]) as [userLookupRow[], unknown];

      if (!patientRows.length) {
        throw new NotFoundError('Patient not found.');
      }

      patientUid = patientRows[0]!.uid;
    } else {
      patientUid = requester.uid;
    }

    const [conflictRows] = await conn.query(
      findConflictingAppointmentQuery,
      [doctor.uid, normalizedAt, normalizedAt]
    ) as [unknown[], unknown];

    if (conflictRows.length !== 0) {
      throw new BadRequestError(
        'Doctor already has an appointment at the requested time.'
      );
    }

    const [insertResult] = await conn.query(insertAppointmentQuery, [
      doctor.uid,
      patientUid,
      normalizedAt,
    ]) as [insertResult, unknown];

    const [appointmentRows] = await conn.query(
      getNewAppointmentQuery,
      [insertResult.insertId]
    ) as [newAppointmentRow[], unknown];

    const appointment = appointmentRows[0]!;

    return {
      doctorName : appointment.doctorName,
      patientName : appointment.patientName,
      scheduledAt : appointment.scheduledAt,
      status : appointment.status,
    };
  });
};

export default bookAppointment;
