import { NotFoundError, BadRequestError, ForbiddenError } from '../../../utils/app-error';
import { executeTransaction } from '../../../utils/db';
import { rescheduleAppointmentBody, appointmentResult, updateResult } from '../../../types';
import { PoolConnection } from 'mysql2/promise';

const findAppointmentQuery = `
  SELECT
      a.aid,
      a.doctor_uid AS doctorUid,
      a.patient_uid AS patientUid,
      a.status,
      d.name AS doctorName,
      p.name AS patientName,
      a.scheduled_at AS scheduledAt
    FROM appointments a
  INNER JOIN users d 
    ON d.uid = a.doctor_uid
  INNER JOIN users p 
    ON p.uid = a.patient_uid
  WHERE a.aid = ?`;

const findConflictingAppointmentQuery = `
  SELECT a.aid FROM appointments a
  WHERE 
    a.doctor_uid = ?
    AND 
    a.status = 'scheduled'
    AND 
    a.scheduled_at BETWEEN
      DATE_SUB(?, INTERVAL 30 MINUTE)
      AND
      DATE_ADD(?, INTERVAL 30 MINUTE)
    AND 
    a.aid != ?`;

const updateScheduledAtQuery = `
  UPDATE appointments
    SET 
      scheduled_at = ?, 
      updated_at = NOW()
  WHERE aid = ?`;

interface appointmentRow {
  aid: number;
  doctorUid: number;
  patientUid: number;
  status: appointmentResult['status'];
  doctorName: string;
  patientName: string;
  scheduledAt: string;
}

const rescheduleAppointment = async ({
  appointmentId,
  scheduledAt,
  requester,
}: rescheduleAppointmentBody): Promise<appointmentResult> => {
  return executeTransaction(async (conn: PoolConnection) => {
    const [appointmentRows] = await conn.query(
      findAppointmentQuery,
      [appointmentId]
    ) as [appointmentRow[], unknown];

    if (!appointmentRows.length) {
      throw new NotFoundError('Appointment not found.');
    }

    const appointment = appointmentRows[0]!;

    if (appointment.status === 'cancelled') {
      throw new BadRequestError(
        'Cancelled appointments cannot be rescheduled.'
      );
    }

    if (appointment.status === 'completed') {
      throw new BadRequestError(
        'Completed appointments cannot be rescheduled.'
      );
    }

    if (requester.role === 'doctor' && requester.uid !== appointment.doctorUid) {
      throw new ForbiddenError(
        'You are not authorised to reschedule this appointment.'
      );
    }

    if (requester.role === 'patient' && requester.uid !== appointment.patientUid) {
      throw new ForbiddenError(
        'You are not authorised to reschedule this appointment.'
      );
    }

    const [conflictRows] = await conn.query(
      findConflictingAppointmentQuery,
      [appointment.doctorUid, scheduledAt, scheduledAt, appointmentId]
    ) as [unknown[], unknown];

    if (conflictRows.length !== 0) {
      throw new BadRequestError(
        'Doctor already has an appointment at the requested time.'
      );
    }

    await conn.query( updateScheduledAtQuery , [scheduledAt, appointmentId] );

    return {
      doctorName : appointment.doctorName,
      patientName : appointment.patientName,
      scheduledAt : scheduledAt,
      status : appointment.status,
    };
  });
};

export default rescheduleAppointment;
