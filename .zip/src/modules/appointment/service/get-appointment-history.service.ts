import { executeQuery } from '../../../utils/db';
import {
  authUser,
  doctorAppointmentHistoryRow,
  patientAppointmentHistoryRow,
} from '../../../types';

const getHistoryForDocQuery = `
  SELECT
      p.name AS patientName,
      p.email AS patientEmail,
      DATE_FORMAT(a.scheduled_at, '%Y-%m-%d %H:%i:%s') AS scheduledAt,
      a.status
    FROM appointments a
  INNER JOIN users p 
    ON p.uid = a.patient_uid
  WHERE a.doctor_uid = ?
    AND a.scheduled_at < NOW()
  ORDER BY a.scheduled_at DESC`;

const getHistoryForPatQuery = `
  SELECT
      d.name AS doctorName,
      d.email AS doctorEmail,
      dc.supportedSpecialization,
      dc.consultation_fee AS consultationFee,
      DATE_FORMAT(a.scheduled_at, '%Y-%m-%d %H:%i:%s') AS scheduledAt,
      a.status
    FROM appointments a
  INNER JOIN users d 
    ON d.uid = a.doctor_uid
  INNER JOIN doctors dc 
    ON dc.uid = a.doctor_uid
  WHERE a.patient_uid = ?
    AND a.scheduled_at < NOW()
  ORDER BY a.scheduled_at DESC`;

interface getHistoryInput {
  requester: authUser;
}

const getAppointmentHistory = async (
  { requester, }: getHistoryInput) 
    : Promise<doctorAppointmentHistoryRow[] 
    | patientAppointmentHistoryRow[]> => {
  if (requester.role === 'doctor') {
    return executeQuery < doctorAppointmentHistoryRow > ( getHistoryForDocQuery , [requester.uid] );
  }

  return executeQuery < patientAppointmentHistoryRow > ( getHistoryForPatQuery , [requester.uid] );
};

export default getAppointmentHistory;
