import { NotFoundError, BadRequestError } from '../../../utils/app-error';
import { executeQuery } from '../../../utils/db';
import { appointmentResult, updateResult } from '../../../types';

const findAppointmentQuery = `
  SELECT
      a.aid,
      a.status,
      d.name AS doctorName,
      p.name AS patientName,
      a.scheduled_at AS scheduledAt
    FROM appointments a
  INNER JOIN users d 
    ON d.uid = a.doctor_uid
  INNER JOIN users p \
    ON p.uid = a.patient_uid
  WHERE a.aid = ?`;

const cancelAppointmentQuery = `
  UPDATE appointments
    SET 
      status = 'cancelled', 
      updated_at = NOW()
  WHERE aid = ?`;

interface appointmentRow {
  aid: number;
  status: appointmentResult['status'];
  doctorName: string;
  patientName: string;
  scheduledAt: string;
}

interface cancelInput {
  appointmentId: string;
}

const cancelAppointment = async ({ appointmentId }: cancelInput): Promise<appointmentResult> => {
  const appointments = await executeQuery<appointmentRow>(findAppointmentQuery, [appointmentId]);

  if (!appointments.length) {
    throw new NotFoundError('Appointment not found.');
  }

  const appointment = appointments[0]!;

  if (appointment.status === 'cancelled') {
    throw new BadRequestError('Appointment is already cancelled.');
  }

  if (appointment.status === 'completed') {
    throw new BadRequestError('Completed appointments cannot be cancelled.');
  }

  await executeQuery<updateResult>(cancelAppointmentQuery, [appointmentId]);

  return {
    doctorName : appointment.doctorName,
    patientName : appointment.patientName,
    scheduledAt : appointment.scheduledAt,
    status : 'cancelled',
  };
};

export default cancelAppointment;
