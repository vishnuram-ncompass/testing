import { Request, Response, NextFunction } from 'express';
import { responseHandler } from '../../../utils/response-handler';
import rescheduleAppointment from '../service/reschedule-appointment.service';

const rescheduleAppointmentController = async (
  req: Request<{ appointmentId: string }, object, { scheduledAt: string }>,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const result = await rescheduleAppointment({
      appointmentId : req.params.appointmentId,
      scheduledAt : req.body.scheduledAt,
      requester : req.user!,
    });
    responseHandler(
      res, 
      200, 
      'Appointment rescheduled successfully.', 
      result
    );
  } 
  catch (error) {
    next(error);
  }
};

export default rescheduleAppointmentController;
