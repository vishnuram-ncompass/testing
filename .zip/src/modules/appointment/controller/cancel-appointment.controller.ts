import { Request, Response, NextFunction } from 'express';
import { responseHandler } from '../../../utils/response-handler';
import cancelAppointment from '../service/cancel-appointment.service';

const cancelAppointmentController = async (
  req: Request<{ appointmentId: string }>,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const result = await cancelAppointment({
      appointmentId: req.params.appointmentId,
    });
    responseHandler(
      res, 
      200, 
      'Appointment cancelled successfully.', 
      result
    );
  } 
  catch (error) {
    next(error);
  }
};

export default cancelAppointmentController;
