import { Request, Response, NextFunction } from 'express';
import { responseHandler } from '../../../utils/response-handler';
import getAppointmentHistory from '../service/get-appointment-history.service';

const getAppointmentHistoryController = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const result = await getAppointmentHistory({ requester: req.user! });
    responseHandler(
      res, 
      200,
      'Appointment history retrieved successfully.', 
      result
    );
  }
  catch (error) {
    next(error);
  }
};

export default getAppointmentHistoryController;