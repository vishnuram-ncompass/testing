import { Request, Response, NextFunction } from 'express';
import { responseHandler } from '../../../utils/response-handler';
import bookAppointment from '../service/book-appointment.service';
import { bookAppointmentBody } from '../../../types';

const bookAppointmentController = async (
  req: Request<object, object, Omit<bookAppointmentBody, 'requester'>>,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const result = await bookAppointment({
      ...req.body,
      requester: req.user!,
    });
    responseHandler(
      res, 
      201, 
      'Appointment booked successfully.', 
      result
    );
  } 
  catch (error) {
    next(error);
  }
};

export default bookAppointmentController;
