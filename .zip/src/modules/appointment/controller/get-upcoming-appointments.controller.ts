import { Request, Response, NextFunction } from 'express';
import { responseHandler } from '../../../utils/response-handler';
import getUpcomingAppointments from '../service/get-upcoming-appointments.service';

const getUpcomingAppointmentsController = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const result = await getUpcomingAppointments({ requester: req.user! });
    responseHandler(
      res, 
      200, 
      'Upcoming appointments retrieved successfully.', 
      result
    );
  } 
  catch (error) {
    next(error);
  }
};

export default getUpcomingAppointmentsController;
