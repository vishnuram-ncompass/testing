import { Request, Response, NextFunction } from 'express';
import { responseHandler } from '../../../utils/response-handler';
import getTodayAppointments from '../service/get-today-appointments.service';

const getTodayAppointmentsController = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const result = await getTodayAppointments({ requester: req.user! });
    responseHandler(
      res, 
      200, 
      "Today's appointments retrieved successfully.", 
      result
    );
  } catch (error) {
    next(error);
  }
};

export default getTodayAppointmentsController;
