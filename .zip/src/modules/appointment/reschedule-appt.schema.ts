import { IsDateString, IsNotEmpty } from "class-validator";

export class rescheduleAppointment {
    @IsDateString(
            {},
            {
                message : "Invalid date..."
            }
        )
        @IsNotEmpty({
            message : "Please provide appointment date..."
        })
        scheduledAt !: string
}