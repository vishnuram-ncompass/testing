import { NotFoundError, ForbiddenError } from '../../../utils/app-error';
import { executeQuery } from '../../../utils/db';
import { authUser, patientResult } from '../../../types';

interface getPatientInput {
  email: string;
  requester: authUser;
}

const getPatientByEmailQuery = `
  SELECT
      u.uid,
      u.name,
      u.email,
      u.date_of_birth AS dateOfBirth,
      u.phone_number AS phoneNumber,
      u.created_at AS registeredAt
    FROM users u
  INNER JOIN patients p 
    ON p.uid = u.uid
  WHERE 
    u.email = ? 
    AND 
    u.deleted_at IS NULL`;

interface patientRow extends patientResult {
  uid: number;
}

const getPatient = async ({ email, requester }: getPatientInput): Promise<patientResult> => {
  const patients = await executeQuery<patientRow>(getPatientByEmailQuery, [email]);

  if (!patients.length) {
    throw new NotFoundError(
      'Patient not found.'
    );
  }

  const patient = patients[0]!;

  if (requester.role === 'patient' && requester.uid !== patient.uid) {
    throw new ForbiddenError(
      'You are not authorised to view this profile.'
    );
  }

  return {
    name : patient.name,
    email : patient.email,
    dateOfBirth : patient.dateOfBirth,
    phoneNumber : patient.phoneNumber,
    registeredAt : patient.registeredAt,
  };
};

export default getPatient;
