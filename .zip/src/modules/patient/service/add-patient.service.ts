import { ConflictError } from '../../../utils/app-error';
import { executeTransaction } from '../../../utils/db';
import { bcrypt } from '../../../utils/packages';
import { addPatientBody, patientResult, insertResult } from '../../../types';
import { PoolConnection } from 'mysql2/promise';

const findUserByEmailQuery = `
  SELECT 
      u.uid 
    FROM users u
  WHERE 
    u.email = ? 
    AND 
    u.deleted_at IS NULL`;

const insertUserQuery = `
  INSERT INTO users (
    name, 
    email, 
    date_of_birth, 
    phone_number, 
    role
  )
  VALUES (?, ?, ?, ?, 'patient')`;

const insertPasswordQuery = `
  INSERT INTO passwords (
    uid, 
    hashed_password
  ) 
  VALUES (?, ?)`;

const insertPatientQuery = `
  INSERT INTO patients (uid) VALUES (?)`;

const getNewPatientQuery = `
  SELECT
      u.name,
      u.email,
      DATE_FORMAT(u.date_of_birth, '%Y-%m-%d') AS dateOfBirth,
      u.phone_number AS phoneNumber,
      DATE_FORMAT(u.created_at, '%Y-%m-%d  %H:%i:%s') AS registeredAt
    FROM users u
  INNER JOIN patients p 
    ON p.uid = u.uid
  WHERE u.uid = ?`;

interface newPatientRow {
  name: string;
  email: string;
  dateOfBirth: string;
  phoneNumber: string;
  registeredAt: string;
}

const addPatient = async ({
  name,
  email,
  password,
  dateOfBirth,
  phoneNumber,
}: addPatientBody): Promise<patientResult> => {
  return executeTransaction(async (conn: PoolConnection) => {
    const [existing] = await conn.query(findUserByEmailQuery, [email]) as [unknown[], unknown];

    if ((existing as unknown[]).length !== 0) {
      throw new ConflictError('A patient with this email already exists.');
    }

    const [userResult] = await conn.query(insertUserQuery, [
      name, email, dateOfBirth, phoneNumber,
    ]) as [insertResult, unknown];

    const uid = userResult.insertId;
    const hashedPassword = await bcrypt.hash(password, 10);

    await conn.query(insertPasswordQuery, [uid, hashedPassword]);
    await conn.query(insertPatientQuery, [uid]);

    const [rows] = await conn.query(getNewPatientQuery, [uid]) as [newPatientRow[], unknown];
    const newPatient = rows[0]!;

    return {
      name : newPatient.name,
      email : newPatient.email,
      dateOfBirth : newPatient.dateOfBirth,
      phoneNumber : newPatient.phoneNumber,
      registeredAt : newPatient.registeredAt,
    };
  });
};

export default addPatient;
