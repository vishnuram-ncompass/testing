import { executeQuery } from '../../../utils/db';
import { patientRow } from '../../../types';

const getAllActivePatientQuery = `
  SELECT
      u.name,
      u.email,
      DATE_FORMAT(u.date_of_birth, '%Y-%m-%d') AS dateOfBirth,
      u.phone_number AS phoneNumber,
      DATE_FORMAT(u.created_at, '%Y-%m-%d') AS registeredAt
    FROM users u
  INNER JOIN patients p 
    ON p.uid = u.uid
  WHERE 
    u.deleted_at IS NULL
    AND 
    p.status = 'alive'
  ORDER BY u.name ASC`;

const getAllActivePatients = async (): Promise<patientRow[]> => {
  return executeQuery<patientRow>(getAllActivePatientQuery);
};

export default getAllActivePatients;
