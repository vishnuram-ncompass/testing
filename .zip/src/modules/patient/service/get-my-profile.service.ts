import { executeQuery } from '../../../utils/db';
import { NotFoundError } from '../../../utils/app-error';
import { patientResult } from '../../../types';

interface getMyProfileInput {
  uid: number;
}

const getMyProfileQuery = `
  SELECT
      u.name,
      u.email,
      DATE_FORMAT(u.date_of_birth, '%Y-%m-%d') AS dob,
      u.phone_number AS phoneNumber,
      DATE_FORMAT(u.created_at, '%Y-%m-%d') AS registeredAt
    FROM users u
  INNER JOIN patients p 
    ON p.uid = u.uid
  WHERE 
    u.uid = ? 
    AND 
    u.deleted_at IS NULL`;

interface profileRow {
  name: string;
  email: string;
  dob: string;
  phoneNumber: string;
  registeredAt: string;
}

const getMyProfile = async ({ uid }: getMyProfileInput): Promise<patientResult> => {
  const patients = await executeQuery<profileRow>(getMyProfileQuery, [uid]);

  if (!patients.length) {
    throw new NotFoundError('Patient profile not found.');
  }

  const patient = patients[0]!;

  return {
    name : patient.name,
    email : patient.email,
    dateOfBirth : patient.dob,
    phoneNumber : patient.phoneNumber,
    registeredAt : patient.registeredAt,
  };
};

export default getMyProfile;
