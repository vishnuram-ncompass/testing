import { executeQuery } from '../../../utils/db';
import { NotFoundError } from '../../../utils/app-error';
import { updateResult } from '../../../types';

const deletePatientQuery = `
  UPDATE patients
  SET
    status = 'deceased',
    deceased_at = NOW(),
    updated_at = NOW()
  WHERE pid = ?
    AND status != 'deceased'`;

const deletePatient = async (pid: string): Promise<true> => {
  const results = await executeQuery<updateResult>(deletePatientQuery, [pid]);
  const result = results[0];

  if (!result || result.affectedRows === 0) {
    throw new NotFoundError(
      'Patient not found or already deceased.'
    );
  }

  return true;
};

export default deletePatient;
