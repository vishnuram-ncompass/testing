import { express } from '../../utils/packages';

import { authenticate } from '../../middlewares/authenticate.middleware';
import { authorize } from '../../middlewares/authorize.middleware';
// import { validate } from '../../middlewares/validate.middleware';
import { compress } from '../../middlewares/compress.middleware';

// import { addPatientSchema } from './patient.schema';

import addPatientController from './controller/add-patient.controller';
import getAllPatientsController from './controller/get-all-patients.controller';
import getAllActivePatientsController from './controller/get-all-active-patients.controller';
import getPatientController from './controller/get-patient.controller';
import getMyProfileController from './controller/get-my-profile.controller';
import deletePatientController from './controller/delete-patient.controller';
import validater from '../../middlewares/validate';
import { patientSignupSchema } from './schema/add-patient.schema';

const router = express.Router();

router.use(authenticate);

router.get(
  '/me',
  authorize('patient'),
  getMyProfileController
);

router.post(
  '/',
  authorize('admin'),
  // validate(addPatientSchema, 'body'),
  validater( patientSignupSchema ),
  addPatientController
);

router.get(
  '/',
  authorize('admin', 'doctor'),
  compress(),
  getAllPatientsController
);

router.get(
  '/active',
  authorize('admin', 'doctor'),
  compress(),
  getAllActivePatientsController
);

router.get(
  '/:email',
  authorize('admin', 'doctor', 'patient'),
  getPatientController
);

router.delete(
  '/:pid',
  authorize('admin'),
  deletePatientController
);

export default router;
