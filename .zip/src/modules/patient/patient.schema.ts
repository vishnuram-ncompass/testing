import { Joi } from '../../utils/packages';

export const addPatientSchema = Joi.object({

  name: Joi
    .string()
    .pattern(/^[A-Za-z\s]+$/)
    .min(2)
    .max(100)
    .required()
    .messages({
      'string.pattern.base' : 
        'Invalid name.',
      'string.min' : 
        'Name must be at least 2 characters.',
      'string.max' :
        'Name must be at most 100 characters.',
      'any.required' :
        'Name is required.',
    }),

  email: Joi
    .string()
    .email()
    .required()
    .messages({
      'string.email' : 
        'Please provide a valid email address.',
      'any.required' : 
        'Email is required.',
    }),

  password: Joi
    .string()
    .min(8)
    .required()
    .messages({
      'string.min' : 
        'Password must be at least 8 characters.',
      'any.required' : 
        'Password is required.',
    }),

  dateOfBirth: Joi
    .date()
    .iso()
    .less('now')
    .required()
    .messages({
      'date.format' : 
        'Date should be in YYYY-MM-DD format.',
      'date.base' : 
        'Date of birth must be a valid date.',
      'date.less' : 
        'Date of birth must be in the past.',
      'any.required' : 
        'Date of birth is required.',
    }),

  phoneNumber: Joi
    .string()
    .pattern(/^\d{10}$/)
    .required()
    .messages({
      'string.pattern.base' : 
        'Please provide a valid phone number.',
      'any.required' : 
        'Phone number is required.',
    }),
});
