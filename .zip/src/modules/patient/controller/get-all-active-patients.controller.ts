import { Request, Response, NextFunction } from 'express';
import { responseHandler } from '../../../utils/response-handler';
import getAllActivePatients from '../service/get-all-active-patients.service';

const getAllActivePatientsController = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const result = await getAllActivePatients();
    responseHandler(
      res, 
      200, 
      'Patients retrieved successfully.', 
      result
    );
  } 
  catch (error) {
    next(error);
  }
};

export default getAllActivePatientsController;
