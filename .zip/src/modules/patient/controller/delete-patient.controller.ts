import { Request, Response, NextFunction } from 'express';
import { responseHandler } from '../../../utils/response-handler';
import deletePatient from '../service/delete-patient.service';

const deletePatientController = async (
  req: Request<{ pid: string }>,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { pid } = req.params;
    await deletePatient(pid);
    responseHandler(
      res, 
      200, 
      'Patient marked as deceased.'
    );
  } catch (error) {
    next(error);
  }
};

export default deletePatientController;