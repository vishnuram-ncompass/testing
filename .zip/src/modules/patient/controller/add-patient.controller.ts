import { Request, Response, NextFunction } from 'express';
import { responseHandler } from '../../../utils/response-handler';
import addPatient from '../service/add-patient.service';
import { addPatientBody } from '../../../types';

const addPatientController = async (
  req: Request<object, object, addPatientBody>,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const result = await addPatient(req.body);
    responseHandler(
      res, 
      201, 
      'Patient registered successfully.', 
      result
    );
  } 
  catch (error) {
    next(error);
  }
};

export default addPatientController;
