import { Request, Response, NextFunction } from 'express';
import { responseHandler } from '../../../utils/response-handler';
import getMyProfile from '../service/get-my-profile.service';

const getMyProfileController = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const result = await getMyProfile({ uid: req.user!.uid });
    responseHandler(
      res, 
      200, 
      'Profile retrieved successfully.', 
      result
    );
  } 
  catch (error) {
    next(error);
  }
};

export default getMyProfileController;
