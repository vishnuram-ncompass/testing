import { Request, Response, NextFunction } from 'express';
import { responseHandler } from '../../../utils/response-handler';
import getAllPatients from '../service/get-all-patients.service';

const getAllPatientsController = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const result = await getAllPatients();
    responseHandler(
      res, 
      200, 
      'Patients retrieved successfully.', 
      result
    );
  } 
  catch (error) {
    next(error);
  }
};

export default getAllPatientsController;
