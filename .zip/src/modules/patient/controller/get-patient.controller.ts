import { Request, Response, NextFunction } from 'express';
import { responseHandler } from '../../../utils/response-handler';
import getPatient from '../service/get-patient.service';

const getPatientController = async (
  req: Request<{ email: string }>,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const result = await getPatient({
      email : req.params.email,
      requester : req.user!,
    });
    responseHandler(
      res, 
      200, 
      'Patient retrieved successfully.', 
      result
    );
  } 
  catch (error) {
    next(error);
  }
};

export default getPatientController;
