import { Response } from 'express';
import { apiResponse } from '../types';

export const responseHandler = <T>(
  res: Response,
  statusCode: number,
  message: string,
  data: T | null = null
): Response<apiResponse<T>> => {
  const body = data !== null ? { data } : undefined;
  return res.status(statusCode).json({
    statusCode,
    body,
    message,
  });
};