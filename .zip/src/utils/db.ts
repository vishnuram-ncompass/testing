import { PoolConnection } from 'mysql2/promise';
import { createPool } from './packages';

const pool = createPool({
  host : process.env.DB_HOST,
  port : Number(process.env.DB_PORT),
  user : process.env.DB_USER,
  password : process.env.DB_PASSWORD,
  database : process.env.DB_NAME,
});

export const executeQuery = async <T = unknown>(
  query: string,
  values: unknown[] = []
): Promise<T[]> => {
  const [result] = await pool.query(query, values);
  return result as T[];
};

export const executeTransaction = async <T>(
  operations: (connection: PoolConnection) => Promise<T>
): Promise<T> => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const result = await operations(connection);
    await connection.commit();
    return result;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};
