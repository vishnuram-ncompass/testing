import 'dotenv/config';
import 'reflect-metadata';
import { express } from './utils/packages';
import { globalErrorHandler } from './middlewares/global-error-handler.middleware';
import { AppError } from './utils/app-error';
import { compress } from './middlewares/compress.middleware';
import authRoutes from './modules/auth/auth.routes';
import doctorRoutes from './modules/doctor/doctor.routes';
import patientRoutes from './modules/patient/patient.routes';
import appointmentRoutes from './modules/appointment/appointment.routes';

const app  = express();
const PORT = process.env.PORT ?? 3000;

app.use(compress());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/auth', authRoutes);
app.use('/doctors', doctorRoutes);
app.use('/patients', patientRoutes);
app.use('/appointments', appointmentRoutes);

app.all('*splat', (req, res, next) => {
  next(new AppError(`Route ${req.originalUrl} not found.`, 404));
});

app.use(globalErrorHandler);

app.listen(PORT, () => {
  console.log(`Hospital System running on port ${PORT}`);
});

export default app;
