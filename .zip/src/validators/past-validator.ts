import { ValidatorConstraint, ValidatorConstraintInterface } from "class-validator";

@ValidatorConstraint({
    name : "isPastDate",
    async : false
})

export class IsPastDateConstraint implements ValidatorConstraintInterface{
    validate( value : Date ) : boolean {
        return value.getTime( ) < Date.now();
    }
    defaultMessage() : string{
        return "Date of birth must be in the past.."
    }
}