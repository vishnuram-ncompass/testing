import { Request, Response, NextFunction as nextFunction } from 'express';
import { Schema } from 'joi';
import { AppError } from '../utils/app-error';

type requestProperty = 'body' | 'params' | 'query';

export const validate = (
  schema: Schema, 
  property: requestProperty = 'body'
) =>
  (
    req: Request, 
    res: Response, 
    next: nextFunction
  ): void => {
    const { error } = schema.validate(req[property], {
      errors: { 
        wrap: { 
          label: ''
        } 
      },
    });

    if (error) {
      const message = error.details.map((d) => d.message).join(', ');
      return next(new AppError(message, 400));
    }

    next();
  };
