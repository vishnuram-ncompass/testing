import { Request, Response, NextFunction as nextFunction } from 'express';
import { AppError } from '../utils/app-error';

export const globalErrorHandler = (
  err: AppError | Error,
  req: Request,
  res: Response,
  next: nextFunction
): void => {
  const statusCode = 
    err instanceof AppError ? err.statusCode : 500;
  const message = err.message || 'Internal Server Error';

  res.status(statusCode).json({ statusCode, message });
};
