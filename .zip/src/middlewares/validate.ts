import type { Request , Response , NextFunction } from 'express';
import { plainToInstance } from 'class-transformer';
import { validate as validateInstance } from 'class-validator';
import { AppError } from '../utils/app-error.ts';

type requestProperty = 'body' | 'params' | 'query';

const validate = <T extends object>( 
    dto : new () => T, 
    property : requestProperty = 'body'
) => async ( req : Request , _res : Response , next : NextFunction ) => {
    const instance = plainToInstance( dto , req[ property ] );
    console.log( instance );

    const errors = await validateInstance( instance , {
        whitelist : true,
        forbidNonWhitelisted : true//remove
    });

    if( errors.length ){
        const message = errors
            .map( ( error ) => Object.values( error.constraints ?? {} )[0] )
            .flat()
            .join( ', ' );
        return next( new AppError( message , 400 ) );
    }
    req[ property ] = instance;
    next();
}

export default validate;
