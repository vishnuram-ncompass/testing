import { Request, Response, NextFunction } from 'express';
import { UnauthorizedError, ForbiddenError } from '../utils/app-error';
import { userRole } from '../types';

export const authorize = (...allowedRoles: userRole[]) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.user) {
      return next(new UnauthorizedError('Please log in to proceed...'));
    }

    if (!allowedRoles.includes(req.user.role)) {
      return next(
        new ForbiddenError(
          `Access denied. Allowed roles: ${allowedRoles.join(', ')}`
        )
      );
    }

    next();
  };
};
