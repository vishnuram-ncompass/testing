import { Request, Response, NextFunction } from 'express';
import { jwt } from '../utils/packages';
import { AppError } from '../utils/app-error';
import { executeQuery } from '../utils/db';
import { authUser } from '../types';

declare module 'express-serve-static-core' {
  interface Request {
    user ?: authUser;
  }
}

interface jwtPayload {
  uid: number;
}

interface userRow {
  uid: number;
  name: string;
  email: string;
  role: authUser['role'];
}

const findUserByIDQuery = `
  SELECT
      u.uid,
      u.name,
      u.email,
      u.role
    FROM users u
  WHERE
    u.uid = ?
    AND
    u.deleted_at IS NULL`;

export const authenticate = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new AppError(
        'Token missing. Please log in.', 
        401
      );
    }

    const token = authHeader.split(' ')[1];

    if (!token) {
      throw new AppError(
        'Token missing. Please log in.', 
        401
      );
    }

    let decoded: jwtPayload;
    try {
      decoded = jwt.verify(
        token, 
        process.env.JWT_SECRET as string ) as jwtPayload;
    } 
    catch {
      throw new AppError(
        'Invalid or expired token. Please log in again.', 
        401
      );
    }

    const users = await executeQuery<userRow>(findUserByIDQuery, [decoded.uid]);

    if (!users.length) {
      throw new AppError(
        'Token no longer valid. Please log in again.', 
        401
      );
    }

    req.user = users[0] as authUser;
    next();
  } 
  catch (error) {
    next(error);
  }
};
