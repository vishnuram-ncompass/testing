import { RequestHandler as requestHandler } from 'express' ;
import { compression } from '../utils/packages';

interface compressOptions {
  level?: number;
  threshold?: number;
}

export const compress = (options: compressOptions = {}): requestHandler => {
  const { level = 6, threshold = 1024 } = options;
  return compression({ level, threshold });
};
