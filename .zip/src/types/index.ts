import { Request } from 'express';
export type userRole = 'admin' | 'doctor' | 'patient' ;
export type appointmentStatus = 'scheduled' | 'completed' | 'cancelled' ;
export type patientStatus = 'alive' | 'deceased' ;

export interface authUser {
  uid: number;
  name: string;
  email: string;
  role: userRole;
}

export interface authenticatedRequest extends Request {
  user: authUser;
}

export interface patientSignupBody {
  name: string;
  email: string;
  password: string;
  dateOfBirth: string;
  phoneNumber: string;
}

export interface loginBody {
  email: string;
  password: string;
}

export interface loginResult {
  [key: string]: { email: string } | string;
  token: string;
}

export interface signupResult {
  [key: string]: {
    name: string;
    email: string;
    role: string;
  };
}

export type supportedSpecialization =
  | 'cardiology'
  | 'neurology'
  | 'orthopedics'
  | 'dermatology'
  | 'pediatrics'
  | 'oncology'
  | 'gastroenterology'
  | 'urology'
  | 'psychiatry'
  | 'radiology'
  | 'ophthalmology'
  | 'ent';

export interface addDoctorBody {
  name: string;
  email: string;
  password: string;
  specialization: supportedSpecialization;
  consultationFee: number;
  phoneNumber?: string;
  dateOfBirth: string;
}

export interface doctorRow {
  uid: number;
  name: string;
  email: string;
  specialization: supportedSpecialization;
  consultationFee: number;
  phoneNumber?: string;
}

export interface doctorResult {
  name: string;
  email: string;
  contact: string | null;
  specialization: supportedSpecialization;
  consultationFee: number;
}

export interface searchDoctorParams {
  email: string;
}

export interface addPatientBody {
  name: string;
  email: string;
  password: string;
  dateOfBirth: string;
  phoneNumber: string;
}

export interface patientRow {
  uid: number;
  name: string;
  email: string;
  dateOfBirth: string;
  phoneNumber: string;
  registeredAt: string;
  dob?: string;
  status?: patientStatus;
}

export interface patientResult {
  name: string;
  email: string;
  dateOfBirth: string;
  phoneNumber: string;
  registeredAt: string;
}

export interface bookAppointmentBody {
  doctorEmail: string;
  patientEmail?: string;
  scheduledAt: string;
  requester: authUser;
}

export interface rescheduleAppointmentBody {
  appointmentId: string;
  scheduledAt: string;
  requester: authUser;
}

export interface cancelAppointmentBody {
  appointmentId: string;
}

export interface appointmentRow {
  aid: number;
  doctorUid: number;
  patientUid: number;
  status: appointmentStatus;
  doctorName: string;
  patientName: string;
  scheduledAt: string;
}

export interface appointmentResult {
  doctorName: string;
  patientName: string;
  scheduledAt: string;
  status: appointmentStatus;
}

export interface doctorAppointmentHistoryRow {
  patientName: string;
  patientEmail: string;
  scheduledAt: string;
  status: appointmentStatus;
}

export interface patientAppointmentHistoryRow {
  doctorName: string;
  doctorEmail: string;
  specialization: supportedSpecialization;
  consultationFee: number;
  scheduledAt: string;
  status: appointmentStatus;
}

export interface insertResult {
  insertId: number;
  affectedRows: number;
}

export interface updateResult {
  affectedRows: number;
  changedRows: number;
}

export interface apiResponse<T = unknown> {
  statusCode: number;
  message: string;
  body?: { data: T };
}
